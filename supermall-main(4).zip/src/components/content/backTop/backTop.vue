<template>
  <div class="back-top">
    <img src="~assets/images/common/top.png" alt="">
  </div>
</template>

<script>
export default {
  name: 'backTop'
}
</script>

<style>
.back-top {
  position: absolute;
  bottom: 50px;
  right: 10px;
}

.back-top img {
  height: 45px;
  width: 45px;
}
</style>